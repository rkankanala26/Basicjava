package q5;

import q5.package1.Car;
//import q5.package2.Car;

public class Application {

	public static void main(String[] args) {
		Car car1 = new Car();
		Car car2 = new Car();
		car1.start("Toyota","Camry");
//		car2.display("Honda","Accord",2004);
		

	}

}
