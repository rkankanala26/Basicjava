package q5.package1;

public class Car {
	public void start(String make, String model) {
		System.out.println("From package1"+" Make: "+make+" Model: "+model);

	}

}
