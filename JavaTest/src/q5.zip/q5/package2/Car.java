package q5.package2;

public class Car {
	public void display(String make, String model, int year) {
		System.out.println("From package1"+" Make: "+make+" Model: "+model+" Year: "+year);

	}
}
